﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        components = New ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        txtConfirmEmail = New TextBox()
        lblConfirmEmail = New Label()
        txtEmail = New TextBox()
        lblEmail = New Label()
        txtMobileNum = New TextBox()
        lblMobileNum = New Label()
        lblGuestDetDesc = New Label()
        Label3 = New Label()
        lblLimit2 = New Label()
        lblLimit1 = New Label()
        btnSubmit = New Button()
        pnlTopBar = New Panel()
        lblDateTitle = New Label()
        lblTimeTitle = New Label()
        lblTime = New Label()
        picLogo = New PictureBox()
        lblDate = New Label()
        TimeDateTimer = New Timer(components)
        lblContactDesc = New Label()
        lblBookRefTitle = New Label()
        lblBookRef = New Label()
        checkRoundTrip = New CheckBox()
        lblFlightNum1 = New Label()
        comboFlightNum1 = New ComboBox()
        radioAdult = New RadioButton()
        radioChild = New RadioButton()
        radioInfant = New RadioButton()
        comboFlightNum2 = New ComboBox()
        lblFlightNum2 = New Label()
        groupGuest = New GroupBox()
        btnSearch = New Button()
        txtSearch = New TextBox()
        lblSearch = New Label()
        txtGID = New TextBox()
        lblGID = New Label()
        comboCountryCode = New ComboBox()
        lblCountryCode = New Label()
        btnNext = New Button()
        btnBack = New Button()
        btnDelete = New Button()
        DataGridView1 = New DataGridView()
        btnEdit = New Button()
        comboTitle = New ComboBox()
        DateTimePicker1 = New DateTimePicker()
        txtNationality = New TextBox()
        lblNationality = New Label()
        lblDOB = New Label()
        txtLastName = New TextBox()
        txtFirstName = New TextBox()
        lblTitle = New Label()
        btnClear = New Button()
        lblLastName = New Label()
        lblFirstName = New Label()
        DataGridView2 = New DataGridView()
        groupBooked = New GroupBox()
        BindingSource1 = New BindingSource(components)
        pnlTopBar.SuspendLayout()
        CType(picLogo, ComponentModel.ISupportInitialize).BeginInit()
        groupGuest.SuspendLayout()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        CType(DataGridView2, ComponentModel.ISupportInitialize).BeginInit()
        groupBooked.SuspendLayout()
        CType(BindingSource1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' txtConfirmEmail
        ' 
        txtConfirmEmail.Location = New Point(361, 449)
        txtConfirmEmail.Name = "txtConfirmEmail"
        txtConfirmEmail.Size = New Size(299, 27)
        txtConfirmEmail.TabIndex = 86
        ' 
        ' lblConfirmEmail
        ' 
        lblConfirmEmail.AutoSize = True
        lblConfirmEmail.Font = New Font("Arial", 10.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblConfirmEmail.ForeColor = Color.Black
        lblConfirmEmail.Location = New Point(361, 427)
        lblConfirmEmail.Name = "lblConfirmEmail"
        lblConfirmEmail.Size = New Size(199, 19)
        lblConfirmEmail.TabIndex = 85
        lblConfirmEmail.Text = "Re-enter Email Address:"
        ' 
        ' txtEmail
        ' 
        txtEmail.Location = New Point(50, 449)
        txtEmail.Name = "txtEmail"
        txtEmail.Size = New Size(299, 27)
        txtEmail.TabIndex = 82
        ' 
        ' lblEmail
        ' 
        lblEmail.AutoSize = True
        lblEmail.Font = New Font("Arial", 10.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblEmail.ForeColor = Color.Black
        lblEmail.Location = New Point(49, 428)
        lblEmail.Name = "lblEmail"
        lblEmail.Size = New Size(126, 19)
        lblEmail.TabIndex = 81
        lblEmail.Text = "Email Address:"
        ' 
        ' txtMobileNum
        ' 
        txtMobileNum.Location = New Point(193, 383)
        txtMobileNum.Name = "txtMobileNum"
        txtMobileNum.Size = New Size(234, 27)
        txtMobileNum.TabIndex = 80
        ' 
        ' lblMobileNum
        ' 
        lblMobileNum.AutoSize = True
        lblMobileNum.Font = New Font("Arial", 10.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblMobileNum.ForeColor = Color.Black
        lblMobileNum.Location = New Point(193, 362)
        lblMobileNum.Name = "lblMobileNum"
        lblMobileNum.Size = New Size(132, 19)
        lblMobileNum.TabIndex = 78
        lblMobileNum.Text = "Mobile Number:"
        ' 
        ' lblGuestDetDesc
        ' 
        lblGuestDetDesc.AutoSize = True
        lblGuestDetDesc.Font = New Font("Arial", 10F)
        lblGuestDetDesc.ForeColor = Color.Black
        lblGuestDetDesc.Location = New Point(18, 48)
        lblGuestDetDesc.Name = "lblGuestDetDesc"
        lblGuestDetDesc.Size = New Size(913, 19)
        lblGuestDetDesc.TabIndex = 77
        lblGuestDetDesc.Text = "How many passengers are you booking for? Please specify the number of adults, children, and infants. Maximum of 15 only."
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Arial", 8F)
        Label3.ForeColor = Color.Black
        Label3.Location = New Point(442, 117)
        Label3.Name = "Label3"
        Label3.Size = New Size(95, 16)
        Label3.TabIndex = 76
        Label3.Text = "under 2 years"
        ' 
        ' lblLimit2
        ' 
        lblLimit2.AutoSize = True
        lblLimit2.Font = New Font("Arial", 8F)
        lblLimit2.ForeColor = Color.Black
        lblLimit2.Location = New Point(264, 117)
        lblLimit2.Name = "lblLimit2"
        lblLimit2.Size = New Size(74, 16)
        lblLimit2.TabIndex = 75
        lblLimit2.Text = "2-11 years"
        ' 
        ' lblLimit1
        ' 
        lblLimit1.AutoSize = True
        lblLimit1.Font = New Font("Arial", 8F)
        lblLimit1.ForeColor = Color.Black
        lblLimit1.Location = New Point(86, 117)
        lblLimit1.Name = "lblLimit1"
        lblLimit1.Size = New Size(70, 16)
        lblLimit1.TabIndex = 74
        lblLimit1.Text = "12+ years"
        ' 
        ' btnSubmit
        ' 
        btnSubmit.ForeColor = Color.Black
        btnSubmit.Location = New Point(937, 370)
        btnSubmit.Name = "btnSubmit"
        btnSubmit.Size = New Size(93, 28)
        btnSubmit.TabIndex = 71
        btnSubmit.Text = "Submit"
        btnSubmit.UseVisualStyleBackColor = True
        ' 
        ' pnlTopBar
        ' 
        pnlTopBar.BackColor = Color.FromArgb(CByte(0), CByte(73), CByte(139))
        pnlTopBar.Controls.Add(lblDateTitle)
        pnlTopBar.Controls.Add(lblTimeTitle)
        pnlTopBar.Controls.Add(lblTime)
        pnlTopBar.Controls.Add(picLogo)
        pnlTopBar.Controls.Add(lblDate)
        pnlTopBar.Dock = DockStyle.Top
        pnlTopBar.Location = New Point(0, 0)
        pnlTopBar.Name = "pnlTopBar"
        pnlTopBar.Size = New Size(1241, 77)
        pnlTopBar.TabIndex = 87
        ' 
        ' lblDateTitle
        ' 
        lblDateTitle.AutoSize = True
        lblDateTitle.Font = New Font("Arial", 10.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblDateTitle.ForeColor = Color.Gainsboro
        lblDateTitle.Location = New Point(1003, 15)
        lblDateTitle.Name = "lblDateTitle"
        lblDateTitle.Size = New Size(51, 19)
        lblDateTitle.TabIndex = 91
        lblDateTitle.Text = "Date:"
        lblDateTitle.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' lblTimeTitle
        ' 
        lblTimeTitle.AutoSize = True
        lblTimeTitle.Font = New Font("Arial", 10.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblTimeTitle.ForeColor = Color.Gainsboro
        lblTimeTitle.Location = New Point(1132, 15)
        lblTimeTitle.Name = "lblTimeTitle"
        lblTimeTitle.Size = New Size(52, 19)
        lblTimeTitle.TabIndex = 93
        lblTimeTitle.Text = "Time:"
        lblTimeTitle.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' lblTime
        ' 
        lblTime.BorderStyle = BorderStyle.FixedSingle
        lblTime.Font = New Font("Arial", 10.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblTime.ForeColor = Color.Gainsboro
        lblTime.Location = New Point(967, 38)
        lblTime.Name = "lblTime"
        lblTime.Size = New Size(122, 25)
        lblTime.TabIndex = 94
        lblTime.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' picLogo
        ' 
        picLogo.Image = CType(resources.GetObject("picLogo.Image"), Image)
        picLogo.Location = New Point(30, -11)
        picLogo.Name = "picLogo"
        picLogo.Size = New Size(205, 97)
        picLogo.SizeMode = PictureBoxSizeMode.StretchImage
        picLogo.TabIndex = 0
        picLogo.TabStop = False
        ' 
        ' lblDate
        ' 
        lblDate.BorderStyle = BorderStyle.FixedSingle
        lblDate.Font = New Font("Arial", 10.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblDate.ForeColor = Color.Gainsboro
        lblDate.Location = New Point(1095, 38)
        lblDate.Name = "lblDate"
        lblDate.Size = New Size(122, 25)
        lblDate.TabIndex = 92
        lblDate.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' TimeDateTimer
        ' 
        TimeDateTimer.Enabled = True
        TimeDateTimer.Interval = 1000
        ' 
        ' lblContactDesc
        ' 
        lblContactDesc.AutoSize = True
        lblContactDesc.Font = New Font("Arial", 10F)
        lblContactDesc.ForeColor = Color.Black
        lblContactDesc.Location = New Point(18, 307)
        lblContactDesc.Name = "lblContactDesc"
        lblContactDesc.Size = New Size(684, 19)
        lblContactDesc.TabIndex = 94
        lblContactDesc.Text = "Let us know how we may reach you if there are change or questions related to your booking."
        ' 
        ' lblBookRefTitle
        ' 
        lblBookRefTitle.AutoSize = True
        lblBookRefTitle.Font = New Font("Arial", 12F, FontStyle.Bold)
        lblBookRefTitle.ForeColor = Color.Black
        lblBookRefTitle.Location = New Point(994, 110)
        lblBookRefTitle.Name = "lblBookRefTitle"
        lblBookRefTitle.Size = New Size(80, 24)
        lblBookRefTitle.TabIndex = 95
        lblBookRefTitle.Text = "Ref No."
        ' 
        ' lblBookRef
        ' 
        lblBookRef.BorderStyle = BorderStyle.Fixed3D
        lblBookRef.Location = New Point(1082, 106)
        lblBookRef.Name = "lblBookRef"
        lblBookRef.Size = New Size(135, 26)
        lblBookRef.TabIndex = 96
        lblBookRef.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' checkRoundTrip
        ' 
        checkRoundTrip.AutoSize = True
        checkRoundTrip.Cursor = Cursors.Hand
        checkRoundTrip.Location = New Point(357, 75)
        checkRoundTrip.Name = "checkRoundTrip"
        checkRoundTrip.Size = New Size(110, 23)
        checkRoundTrip.TabIndex = 97
        checkRoundTrip.Text = "Round Trip"
        checkRoundTrip.UseVisualStyleBackColor = True
        ' 
        ' lblFlightNum1
        ' 
        lblFlightNum1.AutoSize = True
        lblFlightNum1.Location = New Point(20, 53)
        lblFlightNum1.Name = "lblFlightNum1"
        lblFlightNum1.Size = New Size(133, 19)
        lblFlightNum1.TabIndex = 98
        lblFlightNum1.Text = "Outbound Flight: "
        ' 
        ' comboFlightNum1
        ' 
        comboFlightNum1.FormattingEnabled = True
        comboFlightNum1.Location = New Point(20, 75)
        comboFlightNum1.Name = "comboFlightNum1"
        comboFlightNum1.Size = New Size(151, 27)
        comboFlightNum1.TabIndex = 99
        ' 
        ' radioAdult
        ' 
        radioAdult.AutoSize = True
        radioAdult.Cursor = Cursors.Hand
        radioAdult.Location = New Point(67, 91)
        radioAdult.Name = "radioAdult"
        radioAdult.Size = New Size(66, 23)
        radioAdult.TabIndex = 104
        radioAdult.TabStop = True
        radioAdult.Text = "Adult"
        radioAdult.UseVisualStyleBackColor = True
        ' 
        ' radioChild
        ' 
        radioChild.AutoSize = True
        radioChild.Cursor = Cursors.Hand
        radioChild.Location = New Point(245, 91)
        radioChild.Name = "radioChild"
        radioChild.Size = New Size(67, 23)
        radioChild.TabIndex = 105
        radioChild.TabStop = True
        radioChild.Text = "Child"
        radioChild.UseVisualStyleBackColor = True
        ' 
        ' radioInfant
        ' 
        radioInfant.AutoSize = True
        radioInfant.Cursor = Cursors.Hand
        radioInfant.Location = New Point(419, 91)
        radioInfant.Name = "radioInfant"
        radioInfant.Size = New Size(71, 23)
        radioInfant.TabIndex = 106
        radioInfant.TabStop = True
        radioInfant.Text = "Infant"
        radioInfant.UseVisualStyleBackColor = True
        ' 
        ' comboFlightNum2
        ' 
        comboFlightNum2.Enabled = False
        comboFlightNum2.FormattingEnabled = True
        comboFlightNum2.Location = New Point(187, 75)
        comboFlightNum2.Name = "comboFlightNum2"
        comboFlightNum2.Size = New Size(151, 27)
        comboFlightNum2.TabIndex = 108
        ' 
        ' lblFlightNum2
        ' 
        lblFlightNum2.AutoSize = True
        lblFlightNum2.Location = New Point(187, 53)
        lblFlightNum2.Name = "lblFlightNum2"
        lblFlightNum2.Size = New Size(122, 19)
        lblFlightNum2.TabIndex = 107
        lblFlightNum2.Text = "Inbound Flight: "
        ' 
        ' groupGuest
        ' 
        groupGuest.BackColor = SystemColors.Control
        groupGuest.Controls.Add(btnSearch)
        groupGuest.Controls.Add(txtSearch)
        groupGuest.Controls.Add(lblSearch)
        groupGuest.Controls.Add(txtGID)
        groupGuest.Controls.Add(lblGID)
        groupGuest.Controls.Add(comboCountryCode)
        groupGuest.Controls.Add(lblCountryCode)
        groupGuest.Controls.Add(btnNext)
        groupGuest.Controls.Add(btnBack)
        groupGuest.Controls.Add(btnDelete)
        groupGuest.Controls.Add(DataGridView1)
        groupGuest.Controls.Add(btnEdit)
        groupGuest.Controls.Add(comboTitle)
        groupGuest.Controls.Add(DateTimePicker1)
        groupGuest.Controls.Add(txtNationality)
        groupGuest.Controls.Add(lblNationality)
        groupGuest.Controls.Add(lblDOB)
        groupGuest.Controls.Add(txtLastName)
        groupGuest.Controls.Add(txtFirstName)
        groupGuest.Controls.Add(lblTitle)
        groupGuest.Controls.Add(btnClear)
        groupGuest.Controls.Add(lblContactDesc)
        groupGuest.Controls.Add(lblLastName)
        groupGuest.Controls.Add(txtConfirmEmail)
        groupGuest.Controls.Add(lblFirstName)
        groupGuest.Controls.Add(btnSubmit)
        groupGuest.Controls.Add(lblGuestDetDesc)
        groupGuest.Controls.Add(lblMobileNum)
        groupGuest.Controls.Add(radioInfant)
        groupGuest.Controls.Add(txtMobileNum)
        groupGuest.Controls.Add(radioChild)
        groupGuest.Controls.Add(radioAdult)
        groupGuest.Controls.Add(lblEmail)
        groupGuest.Controls.Add(txtEmail)
        groupGuest.Controls.Add(Label3)
        groupGuest.Controls.Add(lblConfirmEmail)
        groupGuest.Controls.Add(lblLimit2)
        groupGuest.Controls.Add(lblLimit1)
        groupGuest.Location = New Point(30, 505)
        groupGuest.Name = "groupGuest"
        groupGuest.Size = New Size(1187, 753)
        groupGuest.TabIndex = 109
        groupGuest.TabStop = False
        groupGuest.Text = "Guest Details"
        ' 
        ' btnSearch
        ' 
        btnSearch.ForeColor = Color.Black
        btnSearch.Location = New Point(829, 409)
        btnSearch.Name = "btnSearch"
        btnSearch.Size = New Size(93, 28)
        btnSearch.TabIndex = 132
        btnSearch.Text = "Search"
        btnSearch.UseVisualStyleBackColor = True
        ' 
        ' txtSearch
        ' 
        txtSearch.Location = New Point(800, 448)
        txtSearch.Name = "txtSearch"
        txtSearch.Size = New Size(122, 27)
        txtSearch.TabIndex = 131
        ' 
        ' lblSearch
        ' 
        lblSearch.AutoSize = True
        lblSearch.Font = New Font("Arial", 10.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblSearch.ForeColor = Color.Black
        lblSearch.Location = New Point(703, 448)
        lblSearch.Name = "lblSearch"
        lblSearch.Size = New Size(91, 19)
        lblSearch.TabIndex = 130
        lblSearch.Text = "Search ID:"
        ' 
        ' txtGID
        ' 
        txtGID.Location = New Point(937, 112)
        txtGID.Name = "txtGID"
        txtGID.Size = New Size(122, 27)
        txtGID.TabIndex = 129
        ' 
        ' lblGID
        ' 
        lblGID.AutoSize = True
        lblGID.Font = New Font("Arial", 10.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblGID.ForeColor = Color.Black
        lblGID.Location = New Point(853, 114)
        lblGID.Name = "lblGID"
        lblGID.Size = New Size(78, 19)
        lblGID.TabIndex = 128
        lblGID.Text = "GuestID:"
        ' 
        ' comboCountryCode
        ' 
        comboCountryCode.Enabled = False
        comboCountryCode.FormattingEnabled = True
        comboCountryCode.Items.AddRange(New Object() {"(+63)"})
        comboCountryCode.Location = New Point(50, 383)
        comboCountryCode.Name = "comboCountryCode"
        comboCountryCode.Size = New Size(125, 27)
        comboCountryCode.TabIndex = 127
        comboCountryCode.Text = "(+63)"
        ' 
        ' lblCountryCode
        ' 
        lblCountryCode.AutoSize = True
        lblCountryCode.Font = New Font("Arial", 10.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblCountryCode.ForeColor = Color.Black
        lblCountryCode.Location = New Point(50, 361)
        lblCountryCode.Name = "lblCountryCode"
        lblCountryCode.Size = New Size(125, 19)
        lblCountryCode.TabIndex = 126
        lblCountryCode.Text = "Country Code:"
        ' 
        ' btnNext
        ' 
        btnNext.ForeColor = Color.Black
        btnNext.Location = New Point(1040, 447)
        btnNext.Name = "btnNext"
        btnNext.Size = New Size(93, 28)
        btnNext.TabIndex = 125
        btnNext.Text = "Next"
        btnNext.UseVisualStyleBackColor = True
        ' 
        ' btnBack
        ' 
        btnBack.ForeColor = Color.Black
        btnBack.Location = New Point(937, 447)
        btnBack.Name = "btnBack"
        btnBack.Size = New Size(93, 28)
        btnBack.TabIndex = 124
        btnBack.Text = "Back"
        btnBack.UseVisualStyleBackColor = True
        ' 
        ' btnDelete
        ' 
        btnDelete.ForeColor = Color.Black
        btnDelete.Location = New Point(1040, 370)
        btnDelete.Name = "btnDelete"
        btnDelete.Size = New Size(93, 28)
        btnDelete.TabIndex = 123
        btnDelete.Text = "Delete"
        btnDelete.UseVisualStyleBackColor = True
        ' 
        ' DataGridView1
        ' 
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Location = New Point(50, 501)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.RowHeadersWidth = 51
        DataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        DataGridView1.Size = New Size(1083, 209)
        DataGridView1.TabIndex = 111
        ' 
        ' btnEdit
        ' 
        btnEdit.ForeColor = Color.Black
        btnEdit.Location = New Point(1041, 408)
        btnEdit.Name = "btnEdit"
        btnEdit.Size = New Size(93, 28)
        btnEdit.TabIndex = 122
        btnEdit.Text = "Edit"
        btnEdit.UseVisualStyleBackColor = True
        ' 
        ' comboTitle
        ' 
        comboTitle.FormattingEnabled = True
        comboTitle.Items.AddRange(New Object() {"MR", "MS"})
        comboTitle.Location = New Point(178, 168)
        comboTitle.Name = "comboTitle"
        comboTitle.Size = New Size(76, 27)
        comboTitle.TabIndex = 120
        ' 
        ' DateTimePicker1
        ' 
        DateTimePicker1.Location = New Point(629, 211)
        DateTimePicker1.Name = "DateTimePicker1"
        DateTimePicker1.Size = New Size(163, 27)
        DateTimePicker1.TabIndex = 119
        DateTimePicker1.Value = New Date(2023, 12, 24, 0, 0, 0, 0)
        ' 
        ' txtNationality
        ' 
        txtNationality.Location = New Point(629, 171)
        txtNationality.Name = "txtNationality"
        txtNationality.Size = New Size(163, 27)
        txtNationality.TabIndex = 118
        ' 
        ' lblNationality
        ' 
        lblNationality.AutoSize = True
        lblNationality.Font = New Font("Arial", 10.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblNationality.ForeColor = Color.Black
        lblNationality.Location = New Point(525, 171)
        lblNationality.Name = "lblNationality"
        lblNationality.Size = New Size(98, 19)
        lblNationality.TabIndex = 117
        lblNationality.Text = "Nationality:"
        ' 
        ' lblDOB
        ' 
        lblDOB.AutoSize = True
        lblDOB.Font = New Font("Arial", 10.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblDOB.ForeColor = Color.Black
        lblDOB.Location = New Point(508, 211)
        lblDOB.Name = "lblDOB"
        lblDOB.Size = New Size(115, 19)
        lblDOB.TabIndex = 115
        lblDOB.Text = "Date of Birth:"
        ' 
        ' txtLastName
        ' 
        txtLastName.Location = New Point(178, 251)
        txtLastName.Name = "txtLastName"
        txtLastName.Size = New Size(249, 27)
        txtLastName.TabIndex = 114
        ' 
        ' txtFirstName
        ' 
        txtFirstName.Location = New Point(178, 211)
        txtFirstName.Name = "txtFirstName"
        txtFirstName.Size = New Size(249, 27)
        txtFirstName.TabIndex = 113
        ' 
        ' lblTitle
        ' 
        lblTitle.AutoSize = True
        lblTitle.Font = New Font("Arial", 10.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblTitle.ForeColor = Color.Black
        lblTitle.Location = New Point(124, 171)
        lblTitle.Name = "lblTitle"
        lblTitle.Size = New Size(48, 19)
        lblTitle.TabIndex = 111
        lblTitle.Text = "Title:"
        ' 
        ' btnClear
        ' 
        btnClear.Location = New Point(937, 408)
        btnClear.Name = "btnClear"
        btnClear.Size = New Size(94, 29)
        btnClear.TabIndex = 110
        btnClear.Text = "Clear"
        btnClear.UseVisualStyleBackColor = True
        ' 
        ' lblLastName
        ' 
        lblLastName.AutoSize = True
        lblLastName.Font = New Font("Arial", 10.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblLastName.ForeColor = Color.Black
        lblLastName.Location = New Point(72, 251)
        lblLastName.Name = "lblLastName"
        lblLastName.Size = New Size(98, 19)
        lblLastName.TabIndex = 109
        lblLastName.Text = "Last Name:"
        ' 
        ' lblFirstName
        ' 
        lblFirstName.AutoSize = True
        lblFirstName.Font = New Font("Arial", 10.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblFirstName.ForeColor = Color.Black
        lblFirstName.Location = New Point(72, 214)
        lblFirstName.Name = "lblFirstName"
        lblFirstName.Size = New Size(100, 19)
        lblFirstName.TabIndex = 108
        lblFirstName.Text = "First Name:"
        ' 
        ' DataGridView2
        ' 
        DataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView2.Location = New Point(19, 126)
        DataGridView2.Name = "DataGridView2"
        DataGridView2.RowHeadersWidth = 51
        DataGridView2.Size = New Size(1147, 170)
        DataGridView2.TabIndex = 112
        ' 
        ' groupBooked
        ' 
        groupBooked.Controls.Add(checkRoundTrip)
        groupBooked.Controls.Add(DataGridView2)
        groupBooked.Controls.Add(lblFlightNum1)
        groupBooked.Controls.Add(comboFlightNum1)
        groupBooked.Controls.Add(comboFlightNum2)
        groupBooked.Controls.Add(lblFlightNum2)
        groupBooked.Location = New Point(30, 168)
        groupBooked.Name = "groupBooked"
        groupBooked.Size = New Size(1187, 323)
        groupBooked.TabIndex = 113
        groupBooked.TabStop = False
        groupBooked.Text = "Booked Flights"
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(9F, 19F)
        AutoScaleMode = AutoScaleMode.Font
        AutoScroll = True
        ClientSize = New Size(1262, 681)
        Controls.Add(groupBooked)
        Controls.Add(groupGuest)
        Controls.Add(lblBookRef)
        Controls.Add(lblBookRefTitle)
        Controls.Add(pnlTopBar)
        Font = New Font("Arial", 10.2F)
        MaximizeBox = False
        Name = "Form1"
        Text = "Guest Details"
        pnlTopBar.ResumeLayout(False)
        pnlTopBar.PerformLayout()
        CType(picLogo, ComponentModel.ISupportInitialize).EndInit()
        groupGuest.ResumeLayout(False)
        groupGuest.PerformLayout()
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        CType(DataGridView2, ComponentModel.ISupportInitialize).EndInit()
        groupBooked.ResumeLayout(False)
        groupBooked.PerformLayout()
        CType(BindingSource1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents txtConfirmEmail As TextBox
    Friend WithEvents lblConfirmEmail As Label
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents lblEmail As Label
    Friend WithEvents txtMobileNum As TextBox
    Friend WithEvents lblGuestDetailsTitle As Label
    Friend WithEvents lblMobileNum As Label
    Friend WithEvents lblGuestDetDesc As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents lblLimit2 As Label
    Friend WithEvents lblLimit1 As Label
    Friend WithEvents lblContact As Label
    Friend WithEvents btnSubmit As Button
    Friend WithEvents pnlTopBar As Panel
    Friend WithEvents picLogo As PictureBox
    Friend WithEvents lblTime As Label
    Friend WithEvents lblDate As Label
    Friend WithEvents TimeDateTimer As Timer
    Friend WithEvents lblDateTitle As Label
    Friend WithEvents lblTimeTitle As Label
    Friend WithEvents lblContactDesc As Label
    Friend WithEvents lblBookRefTitle As Label
    Friend WithEvents lblBookRef As Label
    Friend WithEvents checkRoundTrip As CheckBox
    Friend WithEvents lblFlightNum1 As Label
    Friend WithEvents comboFlightNum1 As ComboBox
    Friend WithEvents radioAdult As RadioButton
    Friend WithEvents radioChild As RadioButton
    Friend WithEvents radioInfant As RadioButton
    Friend WithEvents comboFlightNum2 As ComboBox
    Friend WithEvents lblFlightNum2 As Label
    Friend WithEvents groupGuest As GroupBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents lblLastName As Label
    Friend WithEvents lblFirstName As Label
    Friend WithEvents DataGridView2 As DataGridView
    Friend WithEvents btnClear As Button
    Friend WithEvents lblTitle As Label
    Friend WithEvents txtNationality As TextBox
    Friend WithEvents lblNationality As Label
    Friend WithEvents lblDOB As Label
    Friend WithEvents txtLastName As TextBox
    Friend WithEvents txtFirstName As TextBox
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents comboTitle As ComboBox
    Friend WithEvents btnDelete As Button
    Friend WithEvents btnEdit As Button
    Friend WithEvents btnNext As Button
    Friend WithEvents btnBack As Button
    Friend WithEvents groupBooked As GroupBox
    Friend WithEvents comboCountryCode As ComboBox
    Friend WithEvents lblCountryCode As Label
    Friend WithEvents txtGID As TextBox
    Friend WithEvents lblGID As Label
    Friend WithEvents btnSearch As Button
    Friend WithEvents txtSearch As TextBox
    Friend WithEvents lblSearch As Label
    Friend WithEvents BindingSource1 As BindingSource

End Class
