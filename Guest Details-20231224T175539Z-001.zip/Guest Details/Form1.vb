﻿Imports MySql.Data.MySqlClient

Public Class Form1
    Dim con As New MySqlConnection("server=localhost;user=root;password=;database=airline_db;")

    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Dim result As DialogResult = MessageBox.Show("Are you sure you want to exit?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If result = DialogResult.No Then
            e.Cancel = True
        End If
    End Sub

    Private Sub TimeDateTimer_Tick(sender As Object, e As EventArgs) Handles TimeDateTimer.Tick
        lblDate.Text = DateTime.Now.ToString("MM/dd/yyyy")
        lblTime.Text = DateTime.Now.ToString("hh:mm:ss tt")
    End Sub

    Private Sub checkRoundTrip_CheckedChanged(sender As Object, e As EventArgs) Handles checkRoundTrip.CheckedChanged
        comboFlightNum2.Enabled = checkRoundTrip.Checked
    End Sub





    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Set the format to Custom
        DateTimePicker1.Format = DateTimePickerFormat.Custom
        ' Set the custom format string for date only (yyyy/MM/dd)
        DateTimePicker1.CustomFormat = "yyyy/MM/dd"

        DisableControls()

        UpdateDataGridView()
    End Sub





    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        ' Validate data before storing it
        If ValidateData() Then
            ' Store data in the database
            StoreData()

            ' Update the DataGridView
            UpdateDataGridView()

            ' Clear the form fields for the next entry
            ClearFields()
        End If
    End Sub

    Private Sub UpdateDataGridView()
        ' Open the connection
        con.Open()

        ' Fetch data from the database
        Dim query As String = "SELECT * FROM Guest_Records"
        Using adapter As New MySqlDataAdapter(query, con)
            Dim dt As New DataTable()
            adapter.Fill(dt)

            ' Bind the DataTable to the DataGridView
            DataGridView1.DataSource = dt
        End Using

        ' Close the connection
        con.Close()
    End Sub


    Private Function ValidateData() As Boolean
        ' Check if a guest status is selected
        If String.IsNullOrEmpty(GetGuestStatus()) Then
            MessageBox.Show("Please select a guest status (Adult, Child, or Infant).", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        ' Check for 10 digits in txtMobileNum
        If Not IsNumeric(txtMobileNum.Text) OrElse txtMobileNum.Text.Length <> 10 Then
            MessageBox.Show("Mobile number must be a 10-digit numeric value.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtMobileNum.Clear()
            Return False
        End If

        ' Check for matching emails
        If txtEmail.Text.Trim() <> txtConfirmEmail.Text.Trim() Then
            MessageBox.Show("Email and Confirm Email must match.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtEmail.Clear()
            txtConfirmEmail.Clear()
            Return False
        End If

        ' Check for white spaces in all fields
        If ContainsWhiteSpace(txtMobileNum.Text) OrElse ContainsWhiteSpace(txtEmail.Text) OrElse ContainsWhiteSpace(txtConfirmEmail.Text) Then
            MessageBox.Show("Fields cannot contain white spaces.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtMobileNum.Clear()
            txtEmail.Clear()
            txtConfirmEmail.Clear()
            Return False
        End If

        ' If all conditions are met, return True
        Return True
    End Function


    Private Function ContainsWhiteSpace(input As String) As Boolean
        ' Check if the input string contains any white spaces
        Return input.Contains(" ")
    End Function

    Private Sub StoreData()
        ' Open the connection
        con.Open()

        ' Use parameterized query to prevent SQL injection
        Dim guestID As String = txtGID.Text

        ' Check if Guest_ID already exists in the database
        Dim queryCheck As String = "SELECT COUNT(*) FROM Guest_Records WHERE Guest_ID = @Guest_ID"
        Using cmdCheck As New MySqlCommand(queryCheck, con)
            cmdCheck.Parameters.AddWithValue("@Guest_ID", guestID)
            Dim count As Integer = Convert.ToInt32(cmdCheck.ExecuteScalar())

            If count > 0 Then
                ' Guest_ID already exists, perform an update
                Dim queryUpdate As String =
                "UPDATE Guest_Records SET Title = @Title, Guest_FName = @Guest_FName, Guest_LName = @Guest_LName, " &
                "Guest_Status = @Guest_Status, DOB = @DOB, Nationality = @Nationality, CP_Num = @CP_Num, Guest_Email = @Guest_Email " &
                "WHERE Guest_ID = @Guest_ID"

                Using cmdUpdate As New MySqlCommand(queryUpdate, con)
                    ' Assign parameter values from form fields
                    cmdUpdate.Parameters.AddWithValue("@Guest_ID", guestID)
                    cmdUpdate.Parameters.AddWithValue("@Title", comboTitle.SelectedItem.ToString())
                    cmdUpdate.Parameters.AddWithValue("@Guest_FName", txtFirstName.Text)
                    cmdUpdate.Parameters.AddWithValue("@Guest_LName", txtLastName.Text)
                    cmdUpdate.Parameters.AddWithValue("@Guest_Status", GetGuestStatus())
                    cmdUpdate.Parameters.AddWithValue("@DOB", DateTimePicker1.Value)
                    cmdUpdate.Parameters.AddWithValue("@Nationality", txtNationality.Text)
                    cmdUpdate.Parameters.AddWithValue("@CP_Num", txtMobileNum.Text)
                    cmdUpdate.Parameters.AddWithValue("@Guest_Email", txtEmail.Text)

                    ' Execute the update query
                    cmdUpdate.ExecuteNonQuery()
                End Using
            Else
                ' Guest_ID doesn't exist, perform an insert
                Dim queryInsert As String =
                "INSERT INTO Guest_Records (Guest_ID, Title, Guest_FName, Guest_LName, " &
                "Guest_Status, DOB, Nationality, CP_Num, Guest_Email) VALUES (@Guest_ID, @Title, " &
                "@Guest_FName, @Guest_LName, @Guest_Status, @DOB, @Nationality, @CP_Num, @Guest_Email)"

                Using cmdInsert As New MySqlCommand(queryInsert, con)
                    ' Assign parameter values from form fields
                    cmdInsert.Parameters.AddWithValue("@Guest_ID", guestID)
                    cmdInsert.Parameters.AddWithValue("@Title", comboTitle.SelectedItem.ToString())
                    cmdInsert.Parameters.AddWithValue("@Guest_FName", txtFirstName.Text)
                    cmdInsert.Parameters.AddWithValue("@Guest_LName", txtLastName.Text)
                    cmdInsert.Parameters.AddWithValue("@Guest_Status", GetGuestStatus())
                    cmdInsert.Parameters.AddWithValue("@DOB", DateTimePicker1.Value)
                    cmdInsert.Parameters.AddWithValue("@Nationality", txtNationality.Text)
                    cmdInsert.Parameters.AddWithValue("@CP_Num", txtMobileNum.Text)
                    cmdInsert.Parameters.AddWithValue("@Guest_Email", txtEmail.Text)

                    ' Execute the insert query
                    cmdInsert.ExecuteNonQuery()
                End Using
            End If
        End Using

        ' Close the connection
        con.Close()
    End Sub


    Private Function GenerateGuestID() As String
        ' Generate a unique Guest_ID with a space between the alphabet and numbers
        Dim random As New Random()
        Dim randomNumber As Integer = random.Next(1000, 9999)
        Return "GID" & randomNumber.ToString("D4")
    End Function

    Private Function GetGuestStatus() As String
        ' Determine the guest status based on radio buttons
        If radioAdult.Checked Then
            Return "Adult"
        ElseIf radioChild.Checked Then
            Return "Child"
        ElseIf radioInfant.Checked Then
            Return "Infant"
        Else
            Return ""
        End If
    End Function

    Private Sub ClearFields()
        ' Clear all the form fields
        radioAdult.Checked = False
        radioChild.Checked = False
        radioInfant.Checked = False
        comboTitle.SelectedIndex = -1
        txtFirstName.Clear()
        txtLastName.Clear()
        txtNationality.Clear()
        DateTimePicker1.Value = DateTime.Now ' Set to default date or desired date
        txtMobileNum.Clear()
        txtEmail.Clear()
        txtConfirmEmail.Clear()
        generatedGuestID = "" ' Reset the generated Guest ID when clearing fields
        txtGID.Clear()
    End Sub

    Private Sub radioAdult_CheckedChanged(sender As Object, e As EventArgs) Handles radioAdult.CheckedChanged
        ' Enable controls when the Adult radio button is checked
        EnableControls(radioAdult.Checked)
        UpdateGuestID()
    End Sub

    Private Sub radioChild_CheckedChanged(sender As Object, e As EventArgs) Handles radioChild.CheckedChanged
        ' Enable controls when the Child radio button is checked
        EnableControls(radioChild.Checked)
        UpdateGuestID()
    End Sub

    Private Sub radioInfant_CheckedChanged(sender As Object, e As EventArgs) Handles radioInfant.CheckedChanged
        ' Enable controls when the Infant radio button is checked
        EnableControls(radioInfant.Checked)
        UpdateGuestID()
    End Sub

    Private Sub EnableControls(enable As Boolean)
        ' Enable or disable controls based on the provided flag
        comboTitle.Enabled = True
        txtFirstName.Enabled = True
        txtLastName.Enabled = True
        txtNationality.Enabled = True
        DateTimePicker1.Enabled = True
        txtMobileNum.Enabled = True
        txtEmail.Enabled = True
        txtConfirmEmail.Enabled = True
    End Sub

    Private Sub DisableControls()
        ' Disable the controls
        comboTitle.Enabled = False
        txtFirstName.Enabled = False
        txtLastName.Enabled = False
        txtNationality.Enabled = False
        DateTimePicker1.Enabled = False
        txtMobileNum.Enabled = False
        txtEmail.Enabled = False
        txtConfirmEmail.Enabled = False
        txtGID.Enabled = False

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ClearFields()
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        ' Check if a row is selected in the DataGridView
        If DataGridView1.SelectedRows.Count > 0 Then
            ' Get the Guest_ID from the selected row
            Dim guestID As String = DataGridView1.SelectedRows(0).Cells("Guest_ID").Value.ToString()

            ' Confirm deletion with the user
            Dim result As DialogResult = MessageBox.Show("Are you sure you want to delete Guest ID " & guestID & "?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

            If result = DialogResult.Yes Then
                ' Perform the deletion in the database
                DeleteRecord(guestID)

                ' Update the DataGridView
                UpdateDataGridView()
            End If
        Else
            ' Inform the user that no row is selected
            MessageBox.Show("Please select a row to delete.", "No Row Selected", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub

    Private Sub DeleteRecord(guestID As String)
        ' Open the connection
        con.Open()

        ' Delete the record from the database
        Dim query As String = "DELETE FROM Guest_Records WHERE Guest_ID = @Guest_ID"
        Using cmd As New MySqlCommand(query, con)
            cmd.Parameters.AddWithValue("@Guest_ID", guestID)
            cmd.ExecuteNonQuery()
        End Using

        ' Close the connection
        con.Close()
    End Sub

    Private Sub PopulateControlsFromSelectedRow()
        ' Populate controls with data from the selected row in the DataGridView

        ' Example: Assuming "Title" is the column name in the DataGridView
        comboTitle.SelectedItem = DataGridView1.SelectedRows(0).Cells("Title").Value.ToString()

        ' Assuming "Guest_Status" is the column name for the Guest Status (Adult, Child, Infant)
        Dim guestStatus As String = DataGridView1.SelectedRows(0).Cells("Guest_Status").Value.ToString()

        ' Check the corresponding radio button based on the Guest Status
        Select Case guestStatus
            Case "Adult"
                radioAdult.Checked = True
            Case "Child"
                radioChild.Checked = True
            Case "Infant"
                radioInfant.Checked = True
            Case Else
                ' Handle the case where the Guest Status is unknown or not selected
                ' You may choose to leave the radio buttons unchecked or handle it differently
                radioAdult.Checked = False
                radioChild.Checked = False
                radioInfant.Checked = False
        End Select

        ' Assuming "Guest_FName" is the column name for Guest First Name
        txtFirstName.Text = DataGridView1.SelectedRows(0).Cells("Guest_FName").Value.ToString()

        ' Assuming "Guest_LName" is the column name for Guest Last Name
        txtLastName.Text = DataGridView1.SelectedRows(0).Cells("Guest_LName").Value.ToString()

        ' Assuming "Nationality" is the column name for Nationality
        txtNationality.Text = DataGridView1.SelectedRows(0).Cells("Nationality").Value.ToString()

        ' Assuming "DOB" is the column name in the DataGridView
        DateTimePicker1.Value = Convert.ToDateTime(DataGridView1.SelectedRows(0).Cells("DOB").Value)

        ' Assuming "CP_Num" is the column name for Contact Number
        txtMobileNum.Text = DataGridView1.SelectedRows(0).Cells("CP_Num").Value.ToString()

        ' Assuming "Guest_Email" is the column name for Guest Email Address
        txtEmail.Text = DataGridView1.SelectedRows(0).Cells("Guest_Email").Value.ToString()
        'txtConfirmEmail.Text = DataGridView1.SelectedRows(0).Cells("Guest_Email").Value.ToString()

        generatedGuestID = DataGridView1.SelectedRows(0).Cells("Guest_ID").Value.ToString()
        txtGID.Text = generatedGuestID
    End Sub

    Private Sub DataGridView1_SelectionChanged(sender As Object, e As EventArgs) Handles DataGridView1.SelectionChanged
        ' Handle the selection change in the DataGridView
        If DataGridView1.SelectedRows.Count > 0 Then
            ' If a row is selected, populate and enable the controls
            PopulateControlsFromSelectedRow()
            DisableControls()
        Else
            ' If no row is selected, disable the controls
            'DisableControls()
            DataGridView1.ClearSelection()
        End If
    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        ' Handle the Edit button click

        ' Enable controls for editing
        EnableControls(True) ' Pass 'True' to enable the controls
    End Sub

    Private generatedGuestID As String = ""
    Private Sub UpdateGuestID()
        ' Update the Guest ID when the guest status changes
        If generatedGuestID = "" Then
            ' Generate the Guest ID only if it's not already generated
            generatedGuestID = GenerateGuestID()
            txtGID.Text = generatedGuestID
        End If
    End Sub


    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        ' Get the Guest ID to search
        Dim searchGuestID As String = txtSearch.Text.Trim()

        ' Check if the Guest ID is provided
        If String.IsNullOrEmpty(searchGuestID) Then
            MessageBox.Show("Please enter a Guest ID to search.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        ' Search for the Guest ID in the DataGridView
        Dim rowIndex As Integer = FindGuestRowIndex(searchGuestID)

        ' Check if the Guest ID was found
        If rowIndex <> -1 Then
            ' Select and scroll to the found row
            DataGridView1.Rows(rowIndex).Selected = True
            DataGridView1.FirstDisplayedScrollingRowIndex = rowIndex
        Else
            MessageBox.Show("Guest ID not found.", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub


    Private Function FindGuestRowIndex(searchGuestID As String) As Integer
        For Each row As DataGridViewRow In DataGridView1.Rows
            ' Assuming "Guest_ID" is the column name for Guest ID
            Dim guestID As String = row.Cells("Guest_ID").Value.ToString()

            ' Perform a case-insensitive search
            If String.Equals(guestID, searchGuestID, StringComparison.OrdinalIgnoreCase) Then
                ' Return the index of the found row
                Return row.Index
            End If
        Next

        ' Return -1 if the Guest ID is not found
        Return -1
    End Function




End Class
